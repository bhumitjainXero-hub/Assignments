"""Part 1:Taking first name and last name as inputs"""
a = input("Enter the first name: ")
b = input("Enter the last name: ")

"""Part 2: Adding first name and last name for full name"""
c = a + " " + b

"""Part 3 Adding a greeting with full name"""
print("\nBhumitHello", c, "!! Welcome to Python")
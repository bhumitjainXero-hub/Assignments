"""Part 1 Taking 2 numbers as inputs"""
a = float(input("Enter the first number: "))
b = float(input("Enter the second number: "))

"""Part 2 Performing basic mathematical operations"""
c = a+b
d = a-b
e = a*b
f = a/b

"""Part 3 Printing the results in output window"""
print("\nAddition:", c)
print("Subtraction:", d)
print("Multiplication:", e)
print("Division:", f)
